const db = require('./db'); // ajustá la ruta si es necesario

db.get(`SELECT name FROM sqlite_master WHERE type='table' AND name='usuarios'`, [], (err, row) => {
  if (err) {
    console.error('Error al consultar la tabla:', err.message);
  } else if (row) {
    console.log('La tabla "usuarios" SÍ existe.');
  } else {
    console.log('La tabla "usuarios" NO existe.');
  }
});
