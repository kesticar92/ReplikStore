const sqlite3 = require('sqlite3').verbose();
const path = require('path');

// Ruta absoluta en Windows (usa doble barra invertida \\ o path.join para evitar errores)
const dbPath = path.resolve('C:/SQL_LITE/ReplikStore/basedeDatos/bd_replikstore.db');

const db = new sqlite3.Database(dbPath, (err) => {
  if (err) {
    console.error('Error al conectar con la base de datos:', err.message);
  } else {
    console.log('Conexión exitosa a la base de datos SQLite.');
  }
});

module.exports = db;
